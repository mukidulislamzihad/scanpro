#!/usr/bin/env python3
"""
ScanPro Desktop GUI
A cross-platform (Windows / macOS / Linux) desktop front-end for the
ScanPro network + web vulnerability assessment tool, built with Tkinter
(no extra GUI dependencies required beyond fpdf2 for PDF export).

Run with:
    python3 gui.py

For authorized security assessments only. Only scan systems you own
or have explicit written permission to test.

Author: Mukidul Islam Zihad
GitHub:   https://github.com/mukidulislamzihad
LinkedIn: https://www.linkedin.com/in/mukidul-islam-zihad
"""

import io
import json
import queue
import re
import socket
import sys
import threading
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

from modules import network_scan, web_scan, cve_lookup, report, subdomain_enum, nuclei_scan, remediation

APP_TITLE = "ScanPro"
AUTHOR_NAME = "Mukidul Islam Zihad"
AUTHOR_GITHUB = "https://github.com/mukidulislamzihad"
AUTHOR_LINKEDIN = "https://www.linkedin.com/in/mukidul-islam-zihad"

ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
HISTORY_DIR = Path.home() / ".scanpro"
HISTORY_FILE = HISTORY_DIR / "history.json"

# ---------------------------------------------------------------- themes
THEMES = {
    "dark": {
        "BG": "#0f172a", "PANEL": "#1e293b", "BORDER": "#334155",
        "TEXT": "#e2e8f0", "MUTED": "#94a3b8", "ACCENT": "#38bdf8",
        "GREEN": "#4ade80", "YELLOW": "#fbbf24", "RED": "#f87171",
        "LOG_BG": "#0b1220", "FIELD_BG": "#0b1220",
    },
    "light": {
        "BG": "#f1f5f9", "PANEL": "#ffffff", "BORDER": "#cbd5e1",
        "TEXT": "#0f172a", "MUTED": "#475569", "ACCENT": "#0284c7",
        "GREEN": "#16a34a", "YELLOW": "#b45309", "RED": "#dc2626",
        "LOG_BG": "#f8fafc", "FIELD_BG": "#ffffff",
    },
}


def get_downloads_dir() -> str:
    """Best-effort cross-platform Downloads folder, falling back to home."""
    home = Path.home()
    candidates = [home / "Downloads", home / "downloads"]
    for c in candidates:
        if c.is_dir():
            return str(c)
    return str(home)


class QueueStream(io.TextIOBase):
    """Redirect target for stdout that pushes stripped text to a queue so the
    background scan thread can talk to the Tk main thread safely."""

    def __init__(self, q: "queue.Queue"):
        self._q = q

    def write(self, s):
        if s:
            self._q.put(("log", ANSI_RE.sub("", s)))
        return len(s)

    def flush(self):
        pass


class ScanProGUI:
    def __init__(self, root):
        self.root = root
        self.theme_name = "dark"
        self.c = THEMES[self.theme_name]

        self.root.title(f"{APP_TITLE} - Network & Web Vulnerability Assessment")
        self.root.geometry("1040x780")
        self.root.minsize(860, 600)

        self.msg_queue = queue.Queue()
        self.scan_thread = None
        self.scan_running = False
        self.cancel_event = threading.Event()
        self.last_results_list = []      # list of per-target result dicts (current run)
        self.history = self._load_history()

        self._build_style()
        self._build_layout()
        self._refresh_history_view()
        self._poll_queue()

    # =============================================================== style
    def _build_style(self):
        c = self.c
        self.root.configure(bg=c["BG"])
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("TFrame", background=c["BG"])
        style.configure("Panel.TFrame", background=c["PANEL"])
        style.configure("TLabel", background=c["BG"], foreground=c["TEXT"], font=("Segoe UI", 10))
        style.configure("Panel.TLabel", background=c["PANEL"], foreground=c["TEXT"], font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background=c["BG"], foreground=c["MUTED"], font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=c["BG"], foreground=c["ACCENT"], font=("Segoe UI", 18, "bold"))
        style.configure("Sub.TLabel", background=c["BG"], foreground=c["YELLOW"], font=("Segoe UI", 9, "italic"))
        style.configure("Footer.TFrame", background=c["PANEL"])
        style.configure("Footer.TLabel", background=c["PANEL"], foreground=c["MUTED"], font=("Segoe UI", 9))
        style.configure("Link.TLabel", background=c["PANEL"], foreground=c["ACCENT"], font=("Segoe UI", 9, "underline"))

        style.configure("TCheckbutton", background=c["PANEL"], foreground=c["TEXT"], font=("Segoe UI", 10))
        style.map("TCheckbutton", background=[("active", c["PANEL"])])

        style.configure("TEntry", fieldbackground=c["FIELD_BG"], foreground=c["TEXT"], insertcolor=c["TEXT"])
        style.configure("TSpinbox", fieldbackground=c["FIELD_BG"], foreground=c["TEXT"], arrowsize=12)

        style.configure("Accent.TButton", background=c["ACCENT"], foreground="#0b1220",
                        font=("Segoe UI", 10, "bold"), padding=8, borderwidth=0)
        style.map("Accent.TButton", background=[("active", c["ACCENT"]), ("disabled", c["BORDER"])])

        style.configure("Secondary.TButton", background=c["PANEL"], foreground=c["TEXT"],
                        font=("Segoe UI", 10), padding=8, borderwidth=1)
        style.map("Secondary.TButton", background=[("active", c["BORDER"])])

        style.configure("Horizontal.TProgressbar", background=c["ACCENT"], troughcolor=c["PANEL"], borderwidth=0)

        style.configure("Treeview", background=c["LOG_BG"], fieldbackground=c["LOG_BG"],
                        foreground=c["TEXT"], rowheight=26, borderwidth=0)
        style.configure("Treeview.Heading", background=c["PANEL"], foreground=c["TEXT"], font=("Segoe UI", 9, "bold"))
        style.map("Treeview", background=[("selected", c["ACCENT"])], foreground=[("selected", "#0b1220")])

        style.configure("TNotebook", background=c["BG"], borderwidth=0)
        style.configure("TNotebook.Tab", background=c["PANEL"], foreground=c["TEXT"], padding=(14, 6))
        style.map("TNotebook.Tab", background=[("selected", c["ACCENT"])], foreground=[("selected", "#0b1220")])

    # ============================================================== layout
    def _build_layout(self):
        c = self.c
        self.root_pad = ttk.Frame(self.root, padding=16)
        self.root_pad.pack(fill="both", expand=True)

        # ---- header ----
        header = ttk.Frame(self.root_pad)
        header.pack(fill="x", pady=(0, 10))
        title_box = ttk.Frame(header)
        title_box.pack(side="left", anchor="w")
        ttk.Label(title_box, text=f"\U0001F6E1 {APP_TITLE}", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            title_box,
            text="Only run this tool against systems you own or have explicit written authorization to test.",
            style="Sub.TLabel",
        ).pack(anchor="w")

        theme_btn_text = "\u2600 Light mode" if self.theme_name == "dark" else "\U0001F319 Dark mode"
        self.theme_btn = ttk.Button(header, text=theme_btn_text, style="Secondary.TButton", command=self.toggle_theme)
        self.theme_btn.pack(side="right", anchor="n")

        # ---- notebook: Scan tab / History tab ----
        self.notebook = ttk.Notebook(self.root_pad)
        self.notebook.pack(fill="both", expand=True)

        self.scan_tab = ttk.Frame(self.notebook, style="TFrame")
        self.history_tab = ttk.Frame(self.notebook, style="TFrame")
        self.notebook.add(self.scan_tab, text="  Scan  ")
        self.notebook.add(self.history_tab, text="  History  ")

        self._build_scan_tab(self.scan_tab)
        self._build_history_tab(self.history_tab)

        # ---- footer (author credit) ----
        self.footer = tk.Frame(self.root_pad, bg=c["PANEL"], highlightbackground=c["BORDER"], highlightthickness=1)
        self.footer.pack(fill="x", pady=(10, 0))
        footer_inner = ttk.Frame(self.footer, style="Footer.TFrame", padding=(10, 6))
        footer_inner.pack(fill="x")
        ttk.Label(footer_inner, text=f"ScanPro \u00b7 built by {AUTHOR_NAME}", style="Footer.TLabel").pack(side="left")

        link_box = ttk.Frame(footer_inner, style="Footer.TFrame")
        link_box.pack(side="right")
        gh = ttk.Label(link_box, text="GitHub", style="Link.TLabel", cursor="hand2")
        gh.pack(side="left", padx=(0, 14))
        gh.bind("<Button-1>", lambda e: webbrowser.open(AUTHOR_GITHUB))
        li = ttk.Label(link_box, text="LinkedIn", style="Link.TLabel", cursor="hand2")
        li.pack(side="left")
        li.bind("<Button-1>", lambda e: webbrowser.open(AUTHOR_LINKEDIN))

    # ------------------------------------------------------------ scan tab
    def _build_scan_tab(self, parent):
        c = self.c
        panel = tk.Frame(parent, bg=c["PANEL"], highlightbackground=c["BORDER"], highlightthickness=1)
        panel.pack(fill="x", pady=(10, 10))
        inner = ttk.Frame(panel, style="Panel.TFrame", padding=14)
        inner.pack(fill="x")
        for col in range(4):
            inner.columnconfigure(col, weight=1)

        ttk.Label(inner, text="Target(s) \u2014 IP, hostname, or URL. Separate multiple with commas.",
                  style="Panel.TLabel").grid(row=0, column=0, columnspan=4, sticky="w")
        self.target_var = tk.StringVar()
        target_entry = ttk.Entry(inner, textvariable=self.target_var, font=("Consolas", 11))
        target_entry.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(2, 10))
        target_entry.focus_set()

        ttk.Label(inner, text="Ports", style="Panel.TLabel").grid(row=2, column=0, sticky="w")
        self.ports_var = tk.StringVar(value="1-1024")
        ttk.Entry(inner, textvariable=self.ports_var).grid(row=3, column=0, sticky="ew", padx=(0, 8))

        ttk.Label(inner, text="Threads", style="Panel.TLabel").grid(row=2, column=1, sticky="w")
        self.threads_var = tk.StringVar(value="100")
        ttk.Spinbox(inner, from_=1, to=1000, textvariable=self.threads_var, width=8).grid(
            row=3, column=1, sticky="ew", padx=(0, 8))

        ttk.Label(inner, text="Timeout (s)", style="Panel.TLabel").grid(row=2, column=2, sticky="w")
        self.timeout_var = tk.StringVar(value="1.0")
        ttk.Spinbox(inner, from_=0.1, to=30, increment=0.1, textvariable=self.timeout_var, width=8).grid(
            row=3, column=2, sticky="ew", padx=(0, 8))

        ttk.Label(inner, text="NVD API key (optional)", style="Panel.TLabel").grid(row=2, column=3, sticky="w")
        self.apikey_var = tk.StringVar()
        ttk.Entry(inner, textvariable=self.apikey_var, show="*").grid(row=3, column=3, sticky="ew")

        ttk.Label(inner, text="Select which scans to run \u2014 nothing runs unless you check it:",
                  style="Panel.TLabel").grid(row=4, column=0, columnspan=4, sticky="w", pady=(12, 0))

        check_row = ttk.Frame(inner, style="Panel.TFrame")
        check_row.grid(row=5, column=0, columnspan=4, sticky="w", pady=(4, 0))
        self.network_var = tk.BooleanVar(value=False)
        self.web_var = tk.BooleanVar(value=False)
        self.cve_var = tk.BooleanVar(value=False)
        self.subdomains_var = tk.BooleanVar(value=False)
        self.nuclei_var = tk.BooleanVar(value=False)
        self.os_detect_var = tk.BooleanVar(value=False)
        self.stealth_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(check_row, text="Network/port scan", variable=self.network_var).pack(side="left", padx=(0, 16))
        ttk.Checkbutton(check_row, text="Web app scan", variable=self.web_var).pack(side="left", padx=(0, 16))
        ttk.Checkbutton(check_row, text="CVE lookup (needs network scan)", variable=self.cve_var).pack(side="left", padx=(0, 16))
        ttk.Checkbutton(check_row, text="Enumerate subdomains", variable=self.subdomains_var).pack(side="left", padx=(0, 16))
        ttk.Checkbutton(check_row, text="Run nuclei (if installed)", variable=self.nuclei_var).pack(side="left", padx=(0, 16))

        check_row2 = ttk.Frame(inner, style="Panel.TFrame")
        check_row2.grid(row=6, column=0, columnspan=4, sticky="w", pady=(4, 0))
        ttk.Checkbutton(check_row2, text="OS fingerprint (TTL, best-effort, needs network scan)", variable=self.os_detect_var).pack(side="left", padx=(0, 16))
        ttk.Checkbutton(check_row2, text="Stealth mode (timing evasion, needs network scan)", variable=self.stealth_var).pack(side="left", padx=(0, 16))
        ttk.Label(check_row2, text="Subdomain probe limit", style="Panel.TLabel").pack(side="left", padx=(16, 4))
        self.subdomain_limit_var = tk.StringVar(value="150")
        ttk.Spinbox(check_row2, from_=10, to=5000, increment=10, textvariable=self.subdomain_limit_var, width=7).pack(side="left")

        btn_row = ttk.Frame(inner, style="Panel.TFrame")
        btn_row.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(14, 0))
        self.scan_btn = ttk.Button(btn_row, text="Start Scan", style="Accent.TButton", command=self.start_scan)
        self.scan_btn.pack(side="left")
        self.stop_btn = ttk.Button(btn_row, text="Stop Scan", style="Secondary.TButton",
                                    command=self.stop_scan, state="disabled")
        self.stop_btn.pack(side="left", padx=(8, 0))
        self.clear_btn = ttk.Button(btn_row, text="Clear Log", style="Secondary.TButton", command=self.clear_log)
        self.clear_btn.pack(side="left", padx=(8, 0))
        self.save_pdf_btn = ttk.Button(btn_row, text="Save PDF", style="Secondary.TButton",
                                        command=lambda: self.save_report("pdf"), state="disabled")
        self.save_pdf_btn.pack(side="left", padx=(8, 0))

        prog_box = ttk.Frame(btn_row, style="Panel.TFrame")
        prog_box.pack(side="right")
        self.progress_pct_var = tk.StringVar(value="")
        ttk.Label(prog_box, textvariable=self.progress_pct_var, style="Panel.TLabel").pack(side="left", padx=(0, 6))
        self.progress = ttk.Progressbar(prog_box, mode="determinate", maximum=100, length=180)
        self.progress.pack(side="left")

        self.status_var = tk.StringVar(value="Ready.")
        ttk.Label(inner, textvariable=self.status_var, style="Muted.TLabel").grid(
            row=8, column=0, columnspan=4, sticky="w", pady=(8, 0))

        log_frame = tk.Frame(parent, bg=c["PANEL"], highlightbackground=c["BORDER"], highlightthickness=1)
        log_frame.pack(fill="both", expand=True)
        self.log = scrolledtext.ScrolledText(
            log_frame, bg=c["LOG_BG"], fg=c["TEXT"], insertbackground=c["TEXT"],
            font=("Consolas", 10), wrap="word", borderwidth=0, padx=10, pady=10)
        self.log.pack(fill="both", expand=True)
        self.log.tag_config("critical", foreground=c["RED"])
        self.log.tag_config("high", foreground=c["RED"])
        self.log.tag_config("medium", foreground=c["YELLOW"])
        self.log.tag_config("low", foreground=c["ACCENT"])
        self.log.tag_config("good", foreground=c["GREEN"])
        self._log_line("Ready. Enter one or more targets (comma-separated) and click 'Start Scan'.\n")

    # --------------------------------------------------------- history tab
    def _build_history_tab(self, parent):
        c = self.c
        top = ttk.Frame(parent, padding=(0, 10, 0, 6))
        top.pack(fill="x")
        ttk.Label(top, text="Past scans (stored locally on this machine)", style="TLabel").pack(side="left")
        ttk.Button(top, text="Refresh", style="Secondary.TButton", command=self._refresh_history_view).pack(side="right")
        ttk.Button(top, text="Clear History", style="Secondary.TButton", command=self._clear_history).pack(side="right", padx=(0, 8))

        cols = ("time", "target", "ip", "open_ports", "cves", "web_findings")
        self.history_tree = ttk.Treeview(parent, columns=cols, show="headings", height=10)
        for col, label, width in [
            ("time", "Scan time", 150), ("target", "Target", 220), ("ip", "IP", 120),
            ("open_ports", "Open ports", 90), ("cves", "CVEs", 70), ("web_findings", "Web findings", 100),
        ]:
            self.history_tree.heading(col, text=label)
            self.history_tree.column(col, width=width, anchor="w")
        self.history_tree.pack(fill="x", padx=0, pady=(0, 10))
        self.history_tree.bind("<<TreeviewSelect>>", self._on_history_select)

        detail_frame = tk.Frame(parent, bg=c["PANEL"], highlightbackground=c["BORDER"], highlightthickness=1)
        detail_frame.pack(fill="both", expand=True)
        self.history_detail = scrolledtext.ScrolledText(
            detail_frame, bg=c["LOG_BG"], fg=c["TEXT"], insertbackground=c["TEXT"],
            font=("Consolas", 10), wrap="word", borderwidth=0, padx=10, pady=10, state="disabled")
        self.history_detail.pack(fill="both", expand=True)

        export_row = ttk.Frame(parent, padding=(0, 8, 0, 0))
        export_row.pack(fill="x")
        self.hist_export_pdf_btn = ttk.Button(export_row, text="Export PDF", style="Secondary.TButton",
                                               command=lambda: self._export_history_item("pdf"), state="disabled")
        self.hist_export_pdf_btn.pack(side="left")

    # ------------------------------------------------------------- theme
    def toggle_theme(self):
        self.theme_name = "light" if self.theme_name == "dark" else "dark"
        self.c = THEMES[self.theme_name]
        for w in self.root_pad.winfo_children():
            w.destroy()
        self._build_style()
        self._build_layout()
        self._refresh_history_view()

    # ------------------------------------------------------------- logging
    def _log_line(self, text, tag=None):
        self.log.configure(state="normal")
        self.log.insert("end", text, tag) if tag else self.log.insert("end", text)
        self.log.see("end")
        self.log.configure(state="disabled")

    def clear_log(self):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    # --------------------------------------------------------------- queue
    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "log":
                    tag = None
                    low = payload.lower()
                    if "critical" in low:
                        tag = "critical"
                    elif "[high]" in low:
                        tag = "high"
                    elif "[medium]" in low:
                        tag = "medium"
                    elif "[low]" in low:
                        tag = "low"
                    elif "[open]" in low or "[+]" in low:
                        tag = "good"
                    self._log_line(payload, tag)
                elif kind == "status":
                    self.status_var.set(payload)
                elif kind == "progress":
                    self.progress["value"] = payload
                    self.progress_pct_var.set(f"{int(payload)}%")
                elif kind == "done":
                    self._scan_finished(payload)
                elif kind == "error":
                    self._scan_error(payload)
        except queue.Empty:
            pass
        self.root.after(80, self._poll_queue)

    # ------------------------------------------------------------ validate
    def _validate_inputs(self):
        raw = self.target_var.get().strip()
        if not raw:
            messagebox.showwarning(APP_TITLE, "Please enter at least one target (IP, hostname, or URL).")
            return None
        targets = [t.strip() for t in raw.split(",") if t.strip()]
        if not targets:
            messagebox.showwarning(APP_TITLE, "Please enter at least one valid target.")
            return None

        try:
            threads = int(self.threads_var.get())
            if threads < 1:
                raise ValueError
        except ValueError:
            messagebox.showwarning(APP_TITLE, "Threads must be a positive integer.")
            return None

        try:
            timeout = float(self.timeout_var.get())
            if timeout <= 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning(APP_TITLE, "Timeout must be a positive number.")
            return None

        do_network = self.network_var.get()
        do_web = self.web_var.get()
        do_subdomains = self.subdomains_var.get()
        do_nuclei = self.nuclei_var.get()

        if not (do_network or do_web or do_subdomains or do_nuclei):
            messagebox.showwarning(
                APP_TITLE,
                "Nothing is selected. Check at least one scan type "
                "(Network/port scan, Web app scan, Enumerate subdomains, or Run nuclei) before starting.")
            return None

        if do_network:
            try:
                network_scan.parse_port_range(self.ports_var.get().strip())
            except Exception:
                messagebox.showwarning(APP_TITLE, "Invalid port range, e.g. use '1-1024' or '22,80,443'.")
                return None

        try:
            subdomain_limit = int(self.subdomain_limit_var.get())
            if subdomain_limit < 1:
                raise ValueError
        except ValueError:
            messagebox.showwarning(APP_TITLE, "Subdomain probe limit must be a positive integer.")
            return None

        return {
            "targets": targets,
            "ports": self.ports_var.get().strip(),
            "threads": threads,
            "timeout": timeout,
            "api_key": self.apikey_var.get().strip() or None,
            "do_network": do_network,
            "do_web": do_web,
            "do_cve": self.cve_var.get() and do_network,
            "subdomains": do_subdomains,
            "subdomain_limit": subdomain_limit,
            "nuclei": do_nuclei,
            "os_detect": self.os_detect_var.get() and do_network,
            "stealth": self.stealth_var.get() and do_network,
        }

    # ----------------------------------------------------------------scan
    def start_scan(self):
        if self.scan_running:
            return
        params = self._validate_inputs()
        if not params:
            return

        self.clear_log()
        self.save_pdf_btn.configure(state="disabled")
        self.scan_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.progress["value"] = 0
        self.progress_pct_var.set("0%")
        self.status_var.set(f"Scanning {len(params['targets'])} target(s)...")
        self.scan_running = True
        self.cancel_event.clear()

        self.scan_thread = threading.Thread(target=self._run_scan, args=(params,), daemon=True)
        self.scan_thread.start()

    def stop_scan(self):
        if not self.scan_running:
            return
        self.cancel_event.set()
        self.stop_btn.configure(state="disabled")
        self.status_var.set("Stopping scan... (finishing current step)")

    def _run_scan(self, params):
        old_stdout = sys.stdout
        sys.stdout = QueueStream(self.msg_queue)
        targets = params["targets"]
        total = len(targets)
        all_results = []
        cancel_event = self.cancel_event
        try:
            for idx, target in enumerate(targets):
                if cancel_event.is_set():
                    print(f"\n{'='*60}\n Scan stopped by user before target: {target}\n{'='*60}\n")
                    break

                base_pct = (idx / total) * 100
                slice_pct = 100 / total

                results = {
                    "target": target,
                    "scan_time": datetime.now(timezone.utc).isoformat(),
                    "network": None,
                    "web": None,
                    "subdomains": None,
                    "nuclei": None,
                }
                print(f"\n{'='*60}\n TARGET: {target}\n{'='*60}\n")

                if params["do_network"] and not cancel_event.is_set():
                    host = network_scan.resolve_target(target)
                    if host:
                        try:
                            _ip_preview = socket.gethostbyname(host)
                        except socket.error:
                            _ip_preview = "unresolvable"
                        print(f"[*] Starting network scan on {host} ({_ip_preview})\n")
                        net_results = network_scan.scan_host(
                            host, params["ports"], threads=params["threads"], timeout=params["timeout"],
                            stealth=params.get("stealth", False), os_detect=params.get("os_detect", False),
                            cancel_event=cancel_event)
                        results["network"] = net_results
                        self.msg_queue.put(("progress", base_pct + slice_pct * 0.3))

                        if params["do_cve"] and net_results["open_ports"] and not cancel_event.is_set():
                            print("\n[*] Looking up known CVEs for detected services...\n")
                            cve_lookup.enrich_with_cves(net_results, api_key=params["api_key"])
                        self.msg_queue.put(("progress", base_pct + slice_pct * 0.55))
                    else:
                        print("[!] Could not resolve target for network scan, skipping.\n")

                if params["do_web"] and not cancel_event.is_set():
                    url = web_scan.normalize_url(target)
                    print(f"\n[*] Starting web application scan on {url}\n")
                    results["web"] = web_scan.scan_web(url)

                if params.get("subdomains") and not cancel_event.is_set():
                    print(f"\n[*] Enumerating subdomains...\n")
                    results["subdomains"] = subdomain_enum.enumerate_subdomains(
                        target, threads=params["threads"], limit=params.get("subdomain_limit", 150),
                        cancel_event=cancel_event)
                    for entry in results["subdomains"]["results"]:
                        for f in entry.get("findings", []):
                            f.setdefault("remediation", remediation.suggest_for_finding(f))

                if params.get("nuclei") and not cancel_event.is_set():
                    print(f"\n[*] Running nuclei...\n")
                    nuclei_url = web_scan.normalize_url(target)
                    nuclei_findings = nuclei_scan.run_nuclei(nuclei_url, cancel_event=cancel_event)
                    if nuclei_findings is not None:
                        for f in nuclei_findings:
                            f["remediation"] = remediation.suggest_for_finding(f)
                    results["nuclei"] = nuclei_findings

                self.msg_queue.put(("progress", base_pct + slice_pct))
                report.print_summary(results)
                all_results.append(results)

                if cancel_event.is_set():
                    print(f"\n[!] Scan stopped by user.\n")
                    break

            self.msg_queue.put(("done", all_results))

        except Exception as e:
            self.msg_queue.put(("error", str(e)))
        finally:
            sys.stdout = old_stdout

    def _scan_finished(self, results_list):
        self.last_results_list = results_list
        self.scan_running = False
        self.scan_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        was_cancelled = self.cancel_event.is_set()
        self.cancel_event.clear()

        if results_list:
            self.save_pdf_btn.configure(state="normal")

        names = ", ".join(r["target"] for r in results_list) if results_list else "(no targets completed)"
        if was_cancelled:
            self.status_var.set(f"Scan stopped by user: {names}  ({datetime.now().strftime('%H:%M:%S')})")
        else:
            self.status_var.set(f"Scan complete: {names}  ({datetime.now().strftime('%H:%M:%S')})")

        raw_log = self.log.get("1.0", "end")
        for r in results_list:
            self._add_history_entry(r, raw_log)
        self._refresh_history_view()

    def _scan_error(self, message):
        self.scan_running = False
        self.scan_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.cancel_event.clear()
        self.status_var.set("Scan failed.")
        self._log_line(f"\n[!] Error: {message}\n", "critical")
        messagebox.showerror(APP_TITLE, f"Scan failed:\n{message}")

    # -------------------------------------------------------------- export
    def save_report(self, fmt="pdf"):
        if not self.last_results_list:
            return
        # Export the most recently scanned target's results as a PDF report.
        result = self.last_results_list[-1]
        default_name = f"scanpro_{result['target'].replace('/', '_').replace(':', '_')}.pdf"
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf", initialdir=get_downloads_dir(),
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")], initialfile=default_name)
        if not path:
            return
        try:
            self._write_pdf(result, path)
            self.status_var.set(f"Report saved to {path}")
            messagebox.showinfo(APP_TITLE, f"Report saved to:\n{path}")
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Could not save report:\n{e}")

    def _write_pdf(self, result, path):
        from fpdf import FPDF

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 16)
        pdf.cell(0, 10, "ScanPro Vulnerability Report", ln=True)
        pdf.set_font("Helvetica", "", 10)
        pdf.cell(0, 8, f"Target: {result['target']}", ln=True)
        pdf.cell(0, 8, f"Scan time: {result.get('scan_time', '')}", ln=True)

        risk = report.calculate_risk_score(result)
        pdf.set_font("Helvetica", "B", 12)
        pdf.cell(0, 8, f"Security score: {risk['score']}/100 (Grade {risk['grade']})"
                       f" - {risk['total_findings']} total finding(s)", ln=True)
        pdf.ln(4)

        net = result.get("network")
        if net:
            pdf.set_font("Helvetica", "B", 12)
            pdf.cell(0, 8, f"Network: {net.get('host', '')} ({net.get('ip') or 'unresolved'}) - "
                           f"{len(net.get('open_ports', []))} open port(s)", ln=True)
            pdf.set_font("Helvetica", "", 10)
            for p in net.get("open_ports", []):
                line = f"  {p.get('ip') or net.get('ip') or '?'}:{p.get('port')}/tcp  {p.get('service', '')}  {p.get('banner', '')}"
                pdf.multi_cell(0, 6, line[:180])
            cves = net.get("cves")
            if isinstance(cves, list):
                for cve in cves:
                    pdf.multi_cell(0, 6, f"  CVE: {cve}"[:180])
            pdf.ln(3)

        web = result.get("web")
        if web:
            findings = web.get("findings", []) if isinstance(web, dict) else []
            pdf.set_font("Helvetica", "B", 12)
            pdf.cell(0, 8, f"Web application: {web.get('hostname', '')} ({web.get('ip') or 'unresolved'}) "
                           f"- server: {web.get('server', '-')} - {len(findings)} finding(s)", ln=True)
            pdf.set_font("Helvetica", "", 10)
            for f in findings:
                sev = f.get("severity", "") if isinstance(f, dict) else ""
                desc = f.get("description", str(f)) if isinstance(f, dict) else str(f)
                pdf.multi_cell(0, 6, f"  [{sev}] {desc}"[:180])

        subdomains = result.get("subdomains")
        if subdomains:
            pdf.ln(3)
            pdf.set_font("Helvetica", "B", 12)
            alive = sum(1 for r in subdomains["results"] if r["alive"])
            vuln = sum(1 for r in subdomains["results"] if r["findings"])
            resolved = subdomains.get("resolved", alive)
            pdf.cell(0, 8, f"Subdomains: {subdomains['found']} found, {resolved} resolved to an IP, "
                           f"{alive} alive/web-reachable, {vuln} with issue(s)", ln=True)
            pdf.set_font("Helvetica", "", 10)
            for entry in subdomains["results"]:
                ip = entry.get("ip") or "unresolved"
                status = "alive" if entry["alive"] else ("unresolved" if not entry.get("ip") else "no web response")
                pdf.multi_cell(0, 6, f"  {entry['subdomain']}  [{ip}]  ({status}) - {len(entry['findings'])} finding(s)"[:200])

        nuclei = result.get("nuclei")
        if nuclei is not None:
            pdf.ln(3)
            pdf.set_font("Helvetica", "B", 12)
            pdf.cell(0, 8, f"Nuclei: {len(nuclei)} finding(s)", ln=True)
            pdf.set_font("Helvetica", "", 10)
            for f in nuclei:
                pdf.multi_cell(0, 6, f"  [{f.get('severity','')}] {f.get('name','')} @ {f.get('matched_at','')}"[:180])

        pdf.ln(6)
        pdf.set_font("Helvetica", "I", 8)
        pdf.cell(0, 6, f"Generated by ScanPro - {AUTHOR_GITHUB}", ln=True)
        pdf.output(path)

    # ---------------------------------------------------------- history
    def _load_history(self):
        try:
            HISTORY_DIR.mkdir(exist_ok=True)
            if HISTORY_FILE.exists():
                with open(HISTORY_FILE) as f:
                    return json.load(f)
        except Exception:
            pass
        return []

    def _save_history(self):
        try:
            HISTORY_DIR.mkdir(exist_ok=True)
            with open(HISTORY_FILE, "w") as f:
                json.dump(self.history, f, indent=2, default=str)
        except Exception:
            pass

    def _add_history_entry(self, result, raw_log):
        net = result.get("network") or {}
        web = result.get("web") or {}
        cves = net.get("cves") if net else None
        entry = {
            "time": result.get("scan_time", datetime.now(timezone.utc).isoformat()),
            "target": result.get("target", ""),
            "ip": net.get("ip") or web.get("ip") or "",
            "open_ports": len(net.get("open_ports", [])) if net else 0,
            "cves": len(cves) if isinstance(cves, list) else 0,
            "web_findings": len(web.get("findings", [])) if isinstance(web, dict) else 0,
            "result": result,
            "log": raw_log,
        }
        self.history.insert(0, entry)
        self.history = self.history[:200]  # cap history size
        self._save_history()

    def _refresh_history_view(self):
        if not hasattr(self, "history_tree"):
            return
        for row in self.history_tree.get_children():
            self.history_tree.delete(row)
        for i, entry in enumerate(self.history):
            try:
                ts = datetime.fromisoformat(entry["time"]).strftime("%Y-%m-%d %H:%M")
            except Exception:
                ts = entry.get("time", "")
            self.history_tree.insert("", "end", iid=str(i), values=(
                ts, entry.get("target", ""), entry.get("ip", ""), entry.get("open_ports", 0),
                entry.get("cves", 0), entry.get("web_findings", 0)))
        self.hist_export_pdf_btn.configure(state="disabled")

    def _on_history_select(self, event):
        sel = self.history_tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        entry = self.history[idx]
        self.history_detail.configure(state="normal")
        self.history_detail.delete("1.0", "end")
        self.history_detail.insert("1.0", entry.get("log", "(no log stored)"))
        self.history_detail.configure(state="disabled")
        self._selected_history_idx = idx
        self.hist_export_pdf_btn.configure(state="normal")

    def _export_history_item(self, fmt="pdf"):
        if not hasattr(self, "_selected_history_idx"):
            return
        entry = self.history[self._selected_history_idx]
        result = entry["result"]
        default_name = f"scanpro_{result['target'].replace('/', '_').replace(':', '_')}.pdf"
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf", initialdir=get_downloads_dir(),
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")], initialfile=default_name)
        if not path:
            return
        try:
            self._write_pdf(result, path)
            messagebox.showinfo(APP_TITLE, f"Report saved to:\n{path}")
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Could not save report:\n{e}")

    def _clear_history(self):
        if not self.history:
            return
        if messagebox.askyesno(APP_TITLE, "Clear all saved scan history? This cannot be undone."):
            self.history = []
            self._save_history()
            self._refresh_history_view()
            self.history_detail.configure(state="normal")
            self.history_detail.delete("1.0", "end")
            self.history_detail.configure(state="disabled")


def main():
    root = tk.Tk()
    ScanProGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
