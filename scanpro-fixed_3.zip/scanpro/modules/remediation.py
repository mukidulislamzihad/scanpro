"""
Rule-based remediation advisor.

Given a finding (web header issue, TLS issue, exposed path, CVE, or open
service), returns a short, actionable, plain-English fix suggestion.

This is intentionally rule-based (regex + lookup tables) rather than a live
call to an LLM, so it works fully offline, with zero extra dependencies and
zero extra latency, and its output is deterministic and easy to audit.
"""

import re

# (pattern to match against a finding's lowercased "issue" text, remediation advice)
_FINDING_RULES = [
    (r"strict-transport-security|hsts",
     "Enable HSTS: send `Strict-Transport-Security: max-age=63072000; includeSubDomains` "
     "so browsers always use HTTPS for this host."),
    (r"content-security-policy|\bcsp\b",
     "Add a Content-Security-Policy header (start with `default-src 'self'` and tighten "
     "per-resource) to reduce XSS/data-injection impact."),
    (r"x-content-type-options",
     "Add `X-Content-Type-Options: nosniff` to stop browsers from MIME-sniffing responses."),
    (r"x-frame-options",
     "Add `X-Frame-Options: DENY` (or SAMEORIGIN if framing is required) to prevent clickjacking."),
    (r"referrer-policy",
     "Add `Referrer-Policy: strict-origin-when-cross-origin` to limit referrer data leakage."),
    (r"permissions-policy",
     "Add a `Permissions-Policy` header to explicitly disable unused browser features "
     "(camera, microphone, geolocation, etc.)."),
    (r"information disclosure.*server",
     "Suppress the web server version banner (nginx: `server_tokens off;`, "
     "Apache: `ServerTokens Prod`, `ServerSignature Off`)."),
    (r"information disclosure.*(x-powered-by|x-aspnet)",
     "Remove the framework version header at the application level "
     "(e.g. Express: `app.disable('x-powered-by')`)."),
    (r"plain http",
     "Redirect all HTTP traffic to HTTPS (301) and remove plaintext access entirely."),
    (r"ssl certificate validation failed|certificate verification failed",
     "Install a valid certificate from a trusted CA (e.g. Let's Encrypt); "
     "stop using self-signed/invalid certificates in production."),
    (r"certificate expired",
     "Renew the TLS certificate immediately — an expired cert breaks trust and enables MITM warnings."),
    (r"certificate expires in",
     "Set up automatic certificate renewal (certbot timer/cron) so this doesn't recur."),
    (r"outdated/weak tls",
     "Disable TLS 1.0/1.1 and SSLv2/v3 on the server; support TLS 1.2+ only."),
    (r"\.git/config",
     "Remove the `.git` directory from the web root, or block it in the web server config "
     "(nginx: `location ~ /\\.git { deny all; }`)."),
    (r"\.env",
     "Move `.env` out of the publicly served directory and load secrets via an "
     "environment/secret manager instead."),
]

_SEVERITY_FALLBACK = {
    "critical": "Treat as urgent: patch or restrict this immediately, before it can be exploited.",
    "high": "High priority — schedule a fix soon, this is a significant risk.",
    "medium": "Fix in the next regular maintenance window; don't ignore it indefinitely.",
    "low": "Low risk, but worth fixing as a best practice when convenient.",
    "info": "Informational — no immediate action required, but useful context to be aware of.",
}

# Generic hardening advice keyed by service name (from network_scan.WELL_KNOWN_PORTS)
_SERVICE_ADVICE = {
    "ftp": "Prefer SFTP/FTPS over plain FTP; if FTP is required, disable anonymous login and enforce TLS.",
    "telnet": "Disable Telnet entirely and use SSH instead — Telnet transmits credentials in the clear.",
    "ssh": "Keep SSH patched, disable password auth in favor of keys, and rate-limit/ban repeated failed logins.",
    "mysql": "Don't expose MySQL (3306) to the public internet; restrict to a VPN/private network and patch regularly.",
    "postgresql": "Don't expose PostgreSQL (5432) to the public internet; restrict access to trusted hosts/VPN.",
    "mssql": "Don't expose MSSQL (1433) publicly; use a strong `sa` password and keep it patched.",
    "mongodb": "Enable MongoDB authentication (off by default) and never expose port 27017 publicly.",
    "redis": "Set `requirepass` on Redis (6379) and never expose it to the public internet — it has no auth by default.",
    "elasticsearch": "Enable authentication/TLS on Elasticsearch (9200); an open instance is a common breach vector.",
    "rdp": "Put RDP (3389) behind a VPN/jump host, enable Network Level Authentication, and patch promptly.",
    "vnc": "Set a strong VNC password and never expose port 5900 to the public internet.",
    "smtp": "Ensure the SMTP server isn't an open relay, and keep it on the latest patched version.",
}


def suggest_for_finding(finding: dict) -> str:
    """Return remediation advice for a web/network/nuclei-style finding dict with an 'issue'/'name' text field."""
    text = (finding.get("issue") or finding.get("name") or "").lower()
    for pattern, advice in _FINDING_RULES:
        if re.search(pattern, text):
            return advice
    severity = (finding.get("severity") or "low").lower()
    return _SEVERITY_FALLBACK.get(severity, _SEVERITY_FALLBACK["low"])


def suggest_for_service(service: str) -> str:
    """Generic hardening advice for a detected open service/port."""
    return _SERVICE_ADVICE.get(
        (service or "").lower(),
        "Keep this service updated to its latest stable version, and close/firewall the port if it isn't needed.",
    )


def suggest_for_cve(cve: dict, service: str = "") -> str:
    """Combined remediation for a specific CVE match: patch guidance + generic service hardening."""
    cve_id = cve.get("cve_id", "This CVE")
    score = cve.get("cvss_score")
    score_txt = f" (CVSS {score})" if score is not None else ""
    patch_advice = f"Update/patch the affected software to a version that fixes {cve_id}{score_txt}."
    service_advice = suggest_for_service(service) if service else ""
    return f"{patch_advice} {service_advice}".strip()
