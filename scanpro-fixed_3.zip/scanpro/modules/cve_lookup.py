"""
CVE lookup against the NIST National Vulnerability Database (NVD) API.

Docs: https://nvd.nist.gov/developers/vulnerabilities
Without an API key, NVD rate-limits requests to 5 per rolling 30s window.
Pass --nvd-api-key to raise this to 50 per 30s.
"""

import re
import time
import requests
from .colors import C
from . import remediation

NVD_ENDPOINT = "https://services.nvd.nist.gov/rest/json/cves/2.0"

# Matches things like "OpenSSH_7.4", "Apache/2.4.29", "nginx/1.18.0", "vsftpd 3.0.3"
VERSION_PATTERN = re.compile(
    r"([A-Za-z][A-Za-z0-9\-\._]{1,30})[\/ ]v?(\d+(?:\.\d+){1,3})"
)


def extract_product_version(banner: str):
    """Best-effort extraction of a (product, version) pair from a banner string."""
    if not banner:
        return None
    match = VERSION_PATTERN.search(banner)
    if match:
        product = match.group(1).strip("_-.").lower()
        version = match.group(2)
        return product, version
    return None


def query_nvd(keyword: str, api_key: str = None, max_results: int = 5):
    """Query NVD for CVEs matching a keyword (product + version). Returns a list of dicts."""
    headers = {"apiKey": api_key} if api_key else {}
    params = {"keywordSearch": keyword, "resultsPerPage": max_results}

    try:
        resp = requests.get(NVD_ENDPOINT, params=params, headers=headers, timeout=10)
        if resp.status_code == 403 or resp.status_code == 429:
            return {"error": "rate_limited"}
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as e:
        return {"error": str(e)}

    findings = []
    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        cve_id = cve.get("id")
        descriptions = cve.get("descriptions", [])
        desc_text = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")

        metrics = cve.get("metrics", {})
        score = None
        severity = None
        for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
            if key in metrics and metrics[key]:
                cvss_data = metrics[key][0].get("cvssData", {})
                score = cvss_data.get("baseScore")
                severity = metrics[key][0].get("baseSeverity", cvss_data.get("baseSeverity"))
                break

        findings.append({
            "cve_id": cve_id,
            "description": desc_text[:250],
            "cvss_score": score,
            "severity": severity,
        })

    return findings


def enrich_with_cves(net_results: dict, api_key: str = None):
    """For each open port with a parseable banner, query NVD and attach CVE findings."""
    rate_limit_delay = 6 if not api_key else 0.7  # stay under NVD's window

    for entry in net_results.get("open_ports", []):
        pv = extract_product_version(entry.get("banner", ""))
        if not pv:
            entry["cves"] = []
            continue

        product, version = pv
        keyword = f"{product} {version}"
        result = query_nvd(keyword, api_key=api_key)

        if isinstance(result, dict) and result.get("error"):
            print(f"    {C.YELLOW}[!] CVE lookup skipped for {keyword}: {result['error']}{C.END}")
            entry["cves"] = []
        else:
            for cve in result:
                cve["remediation"] = remediation.suggest_for_cve(cve, service=entry.get("service", ""))
            entry["cves"] = result
            entry["matched_product"] = keyword
            if result:
                worst = max((r["cvss_score"] or 0) for r in result)
                color = C.RED if worst >= 7 else (C.YELLOW if worst >= 4 else C.GREEN)
                print(f"    {color}[cve]{C.END} port {entry['port']} ({keyword}): {len(result)} known CVE(s) found, highest CVSS {worst}")

        time.sleep(rate_limit_delay)
