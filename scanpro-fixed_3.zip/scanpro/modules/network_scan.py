"""Network/host scanning: port discovery, banner grabbing, basic service ID."""

import socket
import concurrent.futures
import subprocess
import platform
import random
import time
import re
from .colors import C

COMMON_SERVICE_PROBES = {
    21: b"",
    22: b"",
    25: b"EHLO scanpro\r\n",
    80: b"HEAD / HTTP/1.0\r\n\r\n",
    443: b"",
}

WELL_KNOWN_PORTS = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns",
    80: "http", 110: "pop3", 111: "rpcbind", 135: "msrpc",
    139: "netbios-ssn", 143: "imap", 443: "https", 445: "microsoft-ds",
    993: "imaps", 995: "pop3s", 1433: "mssql", 1521: "oracle",
    2049: "nfs", 3306: "mysql", 3389: "rdp", 5432: "postgresql",
    5900: "vnc", 6379: "redis", 8080: "http-proxy", 8443: "https-alt",
    9200: "elasticsearch", 27017: "mongodb",
}


def resolve_target(target: str):
    """Strip protocol/path if a URL was passed, then resolve to an IP."""
    host = target
    if "://" in host:
        host = host.split("://", 1)[1]
    host = host.split("/", 1)[0].split(":", 1)[0]
    try:
        socket.gethostbyname(host)
        return host
    except socket.error:
        return None


def parse_port_range(port_spec: str):
    ports = set()
    for part in port_spec.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-")
            ports.update(range(int(start), int(end) + 1))
        elif part:
            ports.add(int(part))
    return sorted(ports)


def grab_banner(host: str, port: int, timeout: float) -> str:
    """Attempt to read a service banner / version string from an open port."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((host, port))
            probe = COMMON_SERVICE_PROBES.get(port, b"")
            if probe:
                s.sendall(probe)
            s.settimeout(timeout)
            data = s.recv(256)
            return data.decode(errors="ignore").strip().replace("\r\n", " | ").replace("\n", " ")
    except Exception:
        return ""


def check_port(host: str, port: int, timeout: float):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            result = s.connect_ex((host, port))
            if result == 0:
                banner = grab_banner(host, port, timeout)
                service = WELL_KNOWN_PORTS.get(port, "unknown")
                return {
                    "port": port,
                    "service": service,
                    "banner": banner,
                }
    except Exception:
        pass
    return None


def guess_os(host: str, timeout: float = 1.5):
    """Best-effort OS family guess from the IP TTL of a single ping reply —
    a lightweight version of the classic TTL heuristic (similar in spirit to
    nmap -O, but far less rigorous). NOT definitive: TTL can be altered by
    firewalls, load balancers, VPNs, or the host's own configuration."""
    system = platform.system().lower()
    if system == "windows":
        cmd = ["ping", "-n", "1", "-w", str(int(timeout * 1000)), host]
    else:
        cmd = ["ping", "-c", "1", "-W", str(max(1, int(timeout))), host]

    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 2)
        text = out.stdout + out.stderr
    except Exception:
        return {"guess": "unknown", "ttl": None, "note": "ping unavailable or blocked"}

    match = re.search(r"ttl[=:]\s*(\d+)", text, re.IGNORECASE)
    if not match:
        return {"guess": "unknown", "ttl": None, "note": "no ICMP reply (host may block ping)"}

    ttl = int(match.group(1))
    if ttl <= 64:
        guess = "Linux / Unix / macOS (likely)"
    elif ttl <= 128:
        guess = "Windows (likely)"
    else:
        guess = "Network device / Solaris / other (likely)"

    return {"guess": guess, "ttl": ttl, "note": "heuristic based on TTL only, not definitive"}


def scan_host(host: str, port_spec: str, threads: int = 100, timeout: float = 1.0,
              stealth: bool = False, os_detect: bool = False, cancel_event=None):
    ports = parse_port_range(port_spec)
    open_ports = []
    cancelled = False

    try:
        ip = socket.gethostbyname(host)
    except socket.error:
        ip = None

    ip_note = f" ({ip})" if ip and ip != host else ""
    mode_note = f" {C.YELLOW}[stealth mode]{C.END}" if stealth else ""
    print(f"    Scanning {len(ports)} ports on {host}{ip_note} with {threads} threads...{mode_note}")

    os_guess = None
    if os_detect:
        print(f"    Attempting OS fingerprint (TTL-based, best-effort)...")
        os_guess = guess_os(host)
        extra = f" (TTL {os_guess['ttl']})" if os_guess.get("ttl") is not None else f" — {os_guess['note']}"
        print(f"    OS guess: {os_guess['guess']}{extra}")

    scan_threads = threads
    if stealth:
        # Timing-only evasion: fewer concurrent connections, randomized port
        # order, and a small random delay before each probe so the traffic
        # doesn't look like a single burst to a simple rate-based IDS. This is
        # NOT packet-level stealth (no SYN/half-open scanning) — that needs
        # raw sockets and root, which is out of scope for a pure-socket tool.
        # Use nmap -sS if you need true half-open scanning.
        scan_threads = min(threads, 15)
        ports = ports.copy()
        random.shuffle(ports)

    def _job(p):
        if stealth:
            time.sleep(random.uniform(0.05, 0.4))
        return check_port(host, p, timeout)

    with concurrent.futures.ThreadPoolExecutor(max_workers=scan_threads) as executor:
        futures = {executor.submit(_job, p): p for p in ports}
        for future in concurrent.futures.as_completed(futures):
            if cancel_event is not None and cancel_event.is_set():
                cancelled = True
                for f in futures:
                    f.cancel()
                print(f"    {C.YELLOW}[!] Scan stopped by user.{C.END}")
                break
            res = future.result()
            if res:
                res["ip"] = ip
                open_ports.append(res)
                banner_note = f" ({res['banner'][:60]})" if res["banner"] else ""
                addr = f"{ip}:{res['port']}" if ip else f"{res['port']}"
                print(f"    {C.GREEN}[open]{C.END} {addr}/tcp  {res['service']}{banner_note}")

    open_ports.sort(key=lambda x: x["port"])
    return {
        "host": host,
        "ip": ip,
        "open_ports": open_ports,
        "ports_scanned": len(ports),
        "os_guess": os_guess,
        "cancelled": cancelled,
    }
