class C:
    """ANSI color codes for terminal output."""
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    CYAN = "\033[96m"
    BOLD = "\033[1m"
    END = "\033[0m"


def severity_color(score: float) -> str:
    """Return a color code based on CVSS score."""
    if score is None:
        return C.CYAN
    if score >= 9.0:
        return C.RED + C.BOLD
    if score >= 7.0:
        return C.RED
    if score >= 4.0:
        return C.YELLOW
    return C.GREEN
