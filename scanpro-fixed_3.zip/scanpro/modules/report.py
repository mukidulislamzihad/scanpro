"""Summary printing, risk scoring, and HTML/CSV/Markdown report generation."""

import csv

from .colors import C, severity_color

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
SEVERITY_WEIGHT = {"critical": 20, "high": 10, "medium": 4, "low": 1, "info": 0.5}


def _all_findings(results: dict):
    """Flatten every finding across network/CVE, web, subdomain, and nuclei results into one list of
    dicts with 'source', 'issue', 'severity', and (when available) 'remediation'."""
    findings = []

    net = results.get("network") or {}
    for p in net.get("open_ports", []):
        for cve in p.get("cves", []):
            findings.append({
                "source": f"network:{p['port']}/{p['service']}",
                "issue": f"{cve.get('cve_id')} - {cve.get('description', '')[:120]}",
                "severity": (cve.get("severity") or "medium").lower(),
                "remediation": cve.get("remediation", ""),
            })

    web = results.get("web") or {}
    for f in web.get("findings", []):
        findings.append({
            "source": f"web:{web.get('url', '')}",
            "issue": f.get("issue", ""),
            "severity": (f.get("severity") or "low").lower(),
            "remediation": f.get("remediation", ""),
        })

    subdomains = results.get("subdomains") or {}
    for entry in subdomains.get("results", []):
        for f in entry.get("findings", []):
            findings.append({
                "source": f"subdomain:{entry['subdomain']}",
                "issue": f.get("issue", ""),
                "severity": (f.get("severity") or "low").lower(),
                "remediation": f.get("remediation", ""),
            })

    for f in results.get("nuclei") or []:
        findings.append({
            "source": f"nuclei:{f.get('matched_at', '')}",
            "issue": f.get("name", f.get("template_id", "nuclei finding")),
            "severity": (f.get("severity") or "info").lower(),
            "remediation": f.get("remediation", ""),
        })

    return findings


def calculate_risk_score(results: dict):
    """
    Roll every finding across all scan types into a single 0-100 security score
    (higher = healthier) plus a letter grade, so a client can see one number
    instead of digging through every section.
    """
    findings = _all_findings(results)
    penalty = sum(SEVERITY_WEIGHT.get(f["severity"], 1) for f in findings)
    score = max(0, round(100 - penalty, 1))

    if score >= 90:
        grade = "A"
    elif score >= 75:
        grade = "B"
    elif score >= 60:
        grade = "C"
    elif score >= 40:
        grade = "D"
    else:
        grade = "F"

    counts = {}
    for f in findings:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1

    return {"score": score, "grade": grade, "total_findings": len(findings), "counts": counts}


def print_summary(results: dict):
    print(f"\n{C.BOLD}{'='*60}\n SCAN SUMMARY: {results['target']}\n{'='*60}{C.END}")

    net = results.get("network")
    if net:
        ip_note = f" — {net.get('ip')}" if net.get("ip") else ""
        print(f"\n{C.BOLD}Network:{C.END} {net['host']}{ip_note} — {net['ports_scanned']} ports scanned, {len(net['open_ports'])} open")
        os_guess = net.get("os_guess")
        if os_guess:
            ttl_note = f" (TTL {os_guess.get('ttl')})" if os_guess.get("ttl") is not None else ""
            print(f"  {C.CYAN}OS guess:{C.END} {os_guess['guess']}{ttl_note}")
        total_cves = sum(len(p.get("cves", [])) for p in net["open_ports"])
        if total_cves:
            print(f"  {C.RED}{total_cves} known CVE(s) found across open services{C.END}")

    web = results.get("web")
    if web:
        findings = sorted(web.get("findings", []), key=lambda f: SEVERITY_ORDER.get(f["severity"], 9))
        counts = {}
        for f in findings:
            counts[f["severity"]] = counts.get(f["severity"], 0) + 1
        ip_note = f" — {web.get('ip')}" if web.get("ip") else ""
        server_note = f" — server: {web.get('server')}" if web.get("server") else ""
        if web.get("server_guess"):
            server_note += f" (heuristic guess: {', '.join(web['server_guess'])})"
        print(f"\n{C.BOLD}Web application:{C.END} {web.get('hostname', '')}{ip_note}{server_note} — {len(findings)} finding(s)")
        for sev in ("critical", "high", "medium", "low"):
            if counts.get(sev):
                color = {"critical": C.RED + C.BOLD, "high": C.RED, "medium": C.YELLOW, "low": C.CYAN}[sev]
                print(f"  {color}{sev.upper()}: {counts[sev]}{C.END}")

    subdomains = results.get("subdomains")
    if subdomains:
        alive = sum(1 for r in subdomains["results"] if r["alive"])
        vuln = sum(1 for r in subdomains["results"] if r["findings"])
        print(f"\n{C.BOLD}Subdomains:{C.END} {subdomains['found']} found, {subdomains['checked']} checked, "
              f"{alive} alive, {C.RED if vuln else C.GREEN}{vuln} with issue(s){C.END}")

    nuclei = results.get("nuclei")
    if nuclei is not None:
        print(f"\n{C.BOLD}Nuclei:{C.END} {len(nuclei)} finding(s)")

    risk = calculate_risk_score(results)
    grade_color = {"A": C.GREEN, "B": C.GREEN, "C": C.YELLOW, "D": C.RED, "F": C.RED + C.BOLD}[risk["grade"]]
    print(f"\n{C.BOLD}Overall security score:{C.END} {grade_color}{risk['score']}/100 (grade {risk['grade']}){C.END} "
          f"— {risk['total_findings']} total finding(s) across all checks")
    print()


def write_html(results: dict, path: str):
    net = results.get("network") or {}
    web = results.get("web") or {}
    subdomains = results.get("subdomains") or {}
    nuclei = results.get("nuclei")
    risk = calculate_risk_score(results)

    rows_ports = ""
    for p in net.get("open_ports", []):
        cve_html = ""
        for cve in p.get("cves", []):
            cve_html += (f"<li><b>{cve['cve_id']}</b> (CVSS {cve['cvss_score']}, {cve['severity']}): "
                         f"{cve['description']}<br><i>Fix: {cve.get('remediation', '')}</i></li>")
        rows_ports += f"""
        <tr>
            <td>{p.get('ip') or net.get('ip') or '-'}</td><td>{p['port']}</td><td>{p['service']}</td><td>{p.get('banner','')}</td>
            <td><ul>{cve_html or '-'}</ul></td>
        </tr>"""

    rows_web = ""
    for f in web.get("findings", []):
        rows_web += (f"<tr><td class='sev-{f['severity']}'>{f['severity'].upper()}</td>"
                      f"<td>{f['issue']}</td><td>{f.get('remediation', '')}</td></tr>")

    rows_sub = ""
    for entry in subdomains.get("results", []):
        status = "alive" if entry["alive"] else "unreachable"
        finding_html = "<br>".join(
            f"<span class='sev-{f['severity']}'>[{f['severity'].upper()}]</span> {f['issue']}"
            for f in entry.get("findings", [])
        ) or "-"
        rows_sub += (f"<tr><td>{entry['subdomain']}</td><td>{entry.get('ip') or '-'}</td>"
                      f"<td>{status}</td><td>{finding_html}</td></tr>")

    rows_nuclei = ""
    for f in (nuclei or []):
        rows_nuclei += (f"<tr><td class='sev-{f['severity']}'>{f['severity'].upper()}</td>"
                         f"<td>{f['name']}</td><td>{f['matched_at']}</td></tr>")

    grade_class = {"A": "sev-low", "B": "sev-low", "C": "sev-medium", "D": "sev-high", "F": "sev-critical"}[risk["grade"]]

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>ScanPro Report - {results['target']}</title>
<style>
body {{ font-family: -apple-system, Arial, sans-serif; background:#0f172a; color:#e2e8f0; margin:0; padding:2rem; }}
h1, h2 {{ color:#38bdf8; }}
table {{ border-collapse: collapse; width:100%; margin-bottom:2rem; background:#1e293b; }}
th, td {{ border:1px solid #334155; padding:8px 12px; text-align:left; font-size:14px; }}
th {{ background:#1e293b; color:#94a3b8; }}
.sev-critical {{ color:#f87171; font-weight:bold; }}
.sev-high {{ color:#fb923c; font-weight:bold; }}
.sev-medium {{ color:#fbbf24; }}
.sev-low {{ color:#38bdf8; }}
.sev-info {{ color:#94a3b8; }}
.meta {{ color:#94a3b8; margin-bottom:1.5rem; }}
.score-badge {{ display:inline-block; font-size:2rem; font-weight:bold; padding:0.5rem 1.2rem;
                 border-radius:8px; background:#1e293b; border:2px solid currentColor; }}
</style></head>
<body>
<h1>ScanPro Report</h1>
<div class="meta">Target: <b>{results['target']}</b> &nbsp;|&nbsp; Scan time: {results['scan_time']}</div>

<div class="{grade_class} score-badge">Security Score: {risk['score']}/100 (Grade {risk['grade']})</div>
<p class="meta">{risk['total_findings']} total finding(s) across network, web, subdomain, and nuclei checks.</p>

<h2>Network / Host Scan</h2>
<p class="meta">Host: <b>{net.get('host','-')}</b> &nbsp;|&nbsp; IP: <b>{net.get('ip') or 'unresolved'}</b>
{f" &nbsp;|&nbsp; OS guess: <b>{net['os_guess']['guess']}</b> (TTL {net['os_guess'].get('ttl')})" if net.get('os_guess') and net['os_guess'].get('ttl') is not None else ""}</p>
<table>
<tr><th>IP</th><th>Port</th><th>Service</th><th>Banner</th><th>Known CVEs &amp; Fix</th></tr>
{rows_ports or '<tr><td colspan="5">No open ports / network scan skipped</td></tr>'}
</table>

<h2>Web Application Scan</h2>
<p class="meta">Host: <b>{web.get('hostname','-')}</b> &nbsp;|&nbsp; IP: <b>{web.get('ip') or 'unresolved'}</b> &nbsp;|&nbsp; Server: <b>{web.get('server','-')}</b>
{f" &nbsp;|&nbsp; Heuristic guess: <b>{', '.join(web['server_guess'])}</b>" if web.get('server_guess') else ""}</p>
<table>
<tr><th>Severity</th><th>Finding</th><th>Suggested Fix</th></tr>
{rows_web or '<tr><td colspan="3">No findings / web scan skipped</td></tr>'}
</table>

<h2>Subdomains</h2>
<table>
<tr><th>Subdomain</th><th>IP</th><th>Status</th><th>Findings</th></tr>
{rows_sub or '<tr><td colspan="4">No subdomain enumeration performed</td></tr>'}
</table>

<h2>Nuclei Findings</h2>
<table>
<tr><th>Severity</th><th>Template</th><th>Matched At</th></tr>
{rows_nuclei or '<tr><td colspan="3">No nuclei scan performed</td></tr>'}
</table>

</body></html>"""

    with open(path, "w") as f:
        f.write(html)


def _report_rows(results: dict):
    """Shared row-building logic for CSV and Markdown export: one row per finding."""
    risk = calculate_risk_score(results)
    header = ["Category", "Item", "Severity", "Finding", "Remediation"]
    rows = [header]

    net = results.get("network") or {}
    for p in net.get("open_ports", []):
        item = f"{p.get('ip') or net.get('ip') or '?'}:{p['port']}/{p['service']}"
        for cve in p.get("cves", []):
            rows.append(["Network/CVE", item, (cve.get("severity") or "").lower(),
                         f"{cve.get('cve_id')}: {cve.get('description', '')[:150]}", cve.get("remediation", "")])

    web = results.get("web") or {}
    web_item = f"{web.get('url', '')} ({web.get('ip') or 'unresolved'}, server: {web.get('server', '-')})"
    for f in web.get("findings", []):
        rows.append(["Web", web_item, f["severity"], f["issue"], f.get("remediation", "")])

    subdomains = results.get("subdomains") or {}
    for entry in subdomains.get("results", []):
        if entry.get("findings"):
            for f in entry["findings"]:
                rows.append(["Subdomain", entry["subdomain"], f["severity"], f["issue"], f.get("remediation", "")])
        else:
            status = "alive, no issues" if entry["alive"] else "unreachable"
            rows.append(["Subdomain", entry["subdomain"], "-", status, ""])

    for f in results.get("nuclei") or []:
        rows.append(["Nuclei", f.get("matched_at", ""), f["severity"], f["name"], f.get("remediation", "")])

    return rows, risk


def write_csv(results: dict, path: str):
    rows, risk = _report_rows(results)
    with open(path, "w", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow([f"# ScanPro Report - {results['target']} - Score {risk['score']}/100 (Grade {risk['grade']})"])
        writer.writerow([f"# Scan time: {results['scan_time']}"])
        writer.writerows(rows)


def write_markdown(results: dict, path: str):
    rows, risk = _report_rows(results)
    header, data_rows = rows[0], rows[1:]

    lines = [
        f"# ScanPro Report — {results['target']}",
        "",
        f"**Scan time:** {results['scan_time']}  ",
        f"**Security score:** {risk['score']}/100 (Grade **{risk['grade']}**)  ",
        f"**Total findings:** {risk['total_findings']}",
        "",
        "| " + " | ".join(header) + " |",
        "|" + "|".join(["---"] * len(header)) + "|",
    ]
    for row in data_rows:
        escaped = [str(c).replace("|", "\\|").replace("\n", " ") for c in row]
        lines.append("| " + " | ".join(escaped) + " |")

    if not data_rows:
        lines.append("| _No findings_ | | | | |")

    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")
