"""Subdomain discovery via certificate transparency logs (crt.sh, no API key
required) plus a light per-subdomain check pass (reuses the web-scan header
and common-path checks) so discovered hosts aren't just listed, but flagged
for issues too.
"""

import re
import socket
import time
import concurrent.futures

import requests

from .colors import C
from . import web_scan

CRT_SH_URL = "https://crt.sh/?q=%25.{domain}&output=json"
# Fallback, passive, no-API-key source used only if crt.sh fails outright or
# comes back empty (crt.sh is frequently overloaded / rate-limited and will
# time out or return a non-JSON error page instead of results).
HACKERTARGET_URL = "https://api.hackertarget.com/hostsearch/?q={domain}"


def _extract_root_domain(target: str) -> str:
    """Best-effort strip of scheme/path/port so crt.sh gets a bare domain."""
    domain = target
    if "://" in domain:
        domain = domain.split("://", 1)[1]
    domain = domain.split("/", 1)[0]
    domain = domain.split(":", 1)[0]
    return domain.lower()


def query_crtsh(domain: str, timeout: int = 20, retries: int = 2):
    """Query crt.sh certificate transparency logs for subdomains of `domain`.
    Returns a sorted, de-duplicated list of hostnames. Passive, read-only,
    no API key required. Retries on failure since crt.sh is frequently
    overloaded and will time out or return an HTML error page instead of
    JSON under load."""
    url = CRT_SH_URL.format(domain=domain)
    last_err = None
    for attempt in range(retries + 1):
        try:
            resp = requests.get(url, timeout=timeout, headers={"User-Agent": "ScanPro/1.0"})
            resp.raise_for_status()
            data = resp.json()
            break
        except requests.RequestException as e:
            last_err = f"request failed ({e})"
        except ValueError:
            last_err = "crt.sh returned a non-JSON response (likely overloaded/rate-limited)"
        if attempt < retries:
            time.sleep(2 * (attempt + 1))
    else:
        print(f"    {C.YELLOW}crt.sh lookup failed: {last_err}{C.END}")
        return []

    wildcard_prefix = re.compile(r"^\*\.")
    found = set()
    for entry in data:
        name_value = entry.get("name_value", "")
        for name in name_value.split("\n"):
            name = wildcard_prefix.sub("", name.strip().lower())
            if name and name.endswith(domain):
                found.add(name)

    return sorted(found)


def query_hackertarget(domain: str, timeout: int = 15):
    """Fallback passive source: hackertarget.com's free hostsearch API
    (DNS-based, no API key). Used only when crt.sh yields nothing."""
    url = HACKERTARGET_URL.format(domain=domain)
    try:
        resp = requests.get(url, timeout=timeout, headers={"User-Agent": "ScanPro/1.0"})
        resp.raise_for_status()
        text = resp.text.strip()
    except requests.RequestException as e:
        print(f"    {C.YELLOW}hackertarget.com lookup failed: {e}{C.END}")
        return []

    if not text or "error" in text.lower() or "API count exceeded" in text:
        return []

    found = set()
    for line in text.splitlines():
        name = line.split(",", 1)[0].strip().lower()
        if name and name.endswith(domain):
            found.add(name)
    return sorted(found)


def _resolve(hostname: str):
    """Cheap liveness check: does the hostname resolve to an IP?"""
    try:
        return socket.gethostbyname(hostname)
    except socket.error:
        return None


def _check_subdomain(hostname: str):
    """Resolve one subdomain, and if it resolves, run a light web-scan pass
    against it. `alive` means it gave back an HTTP response, not just DNS."""
    entry = {"subdomain": hostname, "ip": None, "alive": False, "findings": []}

    ip = _resolve(hostname)
    entry["ip"] = ip
    if not ip:
        return entry

    url = f"https://{hostname}"
    meta, findings = web_scan.check_headers(url)
    if isinstance(meta, dict) and meta.get("error"):
        # HTTPS failed outright (no TLS, refused, etc.) — retry over plain HTTP
        url = f"http://{hostname}"
        meta, findings = web_scan.check_headers(url)

    if isinstance(meta, dict) and meta.get("error"):
        # Resolved via DNS but no web response on either scheme
        return entry

    entry["alive"] = True
    entry["findings"].extend(findings)
    entry["findings"].extend(web_scan.check_common_paths(url))

    return entry


def enumerate_subdomains(target: str, limit: int = 30, threads: int = 30, cancel_event=None):
    """Discover subdomains of `target` via crt.sh, then probe up to `limit`
    of them (DNS resolution + a light web-scan pass) using `threads` workers."""
    domain = _extract_root_domain(target)
    print(f"    Querying crt.sh for {domain} ...")

    all_subdomains = query_crtsh(domain)
    source = "crt.sh"
    if not all_subdomains:
        print(f"    {C.YELLOW}crt.sh returned nothing, trying hackertarget.com as fallback...{C.END}")
        all_subdomains = query_hackertarget(domain)
        source = "hackertarget.com"

    found = len(all_subdomains)
    to_probe = all_subdomains[:limit]
    checked = len(to_probe)

    note = f" (probing first {limit})" if found > limit else ""
    print(f"    Found {found} unique subdomain(s) via {source}{note}")

    results = []
    if to_probe:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, threads)) as executor:
            future_map = {executor.submit(_check_subdomain, h): h for h in to_probe}
            for future in concurrent.futures.as_completed(future_map):
                if cancel_event is not None and cancel_event.is_set():
                    break
                hostname = future_map[future]
                try:
                    entry = future.result()
                except Exception as e:
                    entry = {"subdomain": hostname, "ip": None, "alive": False,
                              "findings": [], "error": str(e)}
                results.append(entry)

                if entry["ip"]:
                    if entry["alive"]:
                        n = len(entry["findings"])
                        color = C.YELLOW if n else C.GREEN
                        print(f"    {color}{entry['subdomain']} ({entry['ip']}) - {n} finding(s){C.END}")
                    else:
                        print(f"    {entry['subdomain']} ({entry['ip']}) - resolved, no HTTP response")
                else:
                    print(f"    {entry['subdomain']} - did not resolve (DNS)")

    results.sort(key=lambda e: e["subdomain"])
    resolved = sum(1 for e in results if e["ip"])

    if results:
        print(f"\n    {C.BOLD}Subdomain{C.END} → {C.BOLD}IP{C.END}")
        for e in results:
            print(f"    {e['subdomain']:<40} {e['ip'] or '(unresolved)'}")

    return {
        "domain": domain,
        "found": found,
        "checked": checked,
        "resolved": resolved,
        "results": results,
        "source": source,
    }
