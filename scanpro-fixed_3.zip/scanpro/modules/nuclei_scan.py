"""
Optional integration with ProjectDiscovery's `nuclei` scanner.

ScanPro does not bundle nuclei or its templates — this module simply shells
out to the `nuclei` binary if it's installed and on PATH, and folds its
findings into ScanPro's own report/risk-score pipeline. If nuclei isn't
installed, this step is skipped gracefully (not an error).

Install nuclei: https://github.com/projectdiscovery/nuclei
"""

import json
import shutil
import subprocess
import time

from .colors import C

_VALID_SEVERITIES = {"info", "low", "medium", "high", "critical"}


def is_available() -> bool:
    return shutil.which("nuclei") is not None


def run_nuclei(url: str, timeout: int = 300, severity: str = None, cancel_event=None):
    """
    Run `nuclei -u <url> -jsonl -silent` and return a list of parsed findings,
    or None if nuclei isn't installed on this machine. Polls the process so an
    optional `cancel_event` (threading.Event) can terminate it early, e.g. from
    a GUI "Stop Scan" button, instead of waiting for the full timeout.
    """
    if not is_available():
        print(f"    {C.YELLOW}[!] nuclei not found on PATH — skipping nuclei scan.{C.END}")
        print(f"    {C.YELLOW}    Install from https://github.com/projectdiscovery/nuclei to enable this.{C.END}")
        return None

    cmd = ["nuclei", "-u", url, "-jsonl", "-silent"]
    if severity:
        cmd += ["-severity", severity]

    print(f"    Running nuclei against {url} (this can take a while)...")
    findings = []
    stdout_text = ""
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        start = time.time()
        while True:
            if proc.poll() is not None:
                stdout_text, _ = proc.communicate()
                break
            if cancel_event is not None and cancel_event.is_set():
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                print(f"    {C.YELLOW}[!] nuclei scan stopped by user.{C.END}")
                stdout_text, _ = proc.communicate()
                break
            if time.time() - start > timeout:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                print(f"    {C.YELLOW}[!] nuclei scan timed out after {timeout}s{C.END}")
                stdout_text, _ = proc.communicate()
                break
            time.sleep(0.3)

        for line in (stdout_text or "").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            info = item.get("info", {})
            sev = (info.get("severity") or "info").lower()
            findings.append({
                "template_id": item.get("template-id"),
                "name": info.get("name", item.get("template-id", "nuclei finding")),
                "severity": sev if sev in _VALID_SEVERITIES else "info",
                "matched_at": item.get("matched-at") or item.get("host") or url,
                "description": info.get("description", ""),
            })
    except Exception as e:
        print(f"    {C.YELLOW}[!] nuclei scan failed: {e}{C.END}")

    for f in findings:
        color = {"critical": C.RED + C.BOLD, "high": C.RED, "medium": C.YELLOW, "low": C.CYAN, "info": C.CYAN}.get(f["severity"], C.CYAN)
        print(f"    {color}[{f['severity']}]{C.END} {f['name']} @ {f['matched_at']}")

    if not findings:
        print(f"    {C.GREEN}[+] nuclei found no matches.{C.END}")

    return findings
