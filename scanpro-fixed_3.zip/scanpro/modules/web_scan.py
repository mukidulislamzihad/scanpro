"""Web application vulnerability assessment: headers, SSL/TLS, common misconfigurations."""

import ssl
import socket
import random
import datetime
import requests
from urllib.parse import urlparse
from .colors import C
from . import remediation

REQUIRED_SECURITY_HEADERS = {
    "Strict-Transport-Security": "Missing HSTS - site may be vulnerable to protocol downgrade / cookie hijacking",
    "Content-Security-Policy": "Missing CSP - increases risk of XSS and data injection attacks",
    "X-Content-Type-Options": "Missing X-Content-Type-Options - browser may MIME-sniff responses",
    "X-Frame-Options": "Missing X-Frame-Options - site may be vulnerable to clickjacking",
    "Referrer-Policy": "Missing Referrer-Policy - may leak referrer data to third parties",
    "Permissions-Policy": "Missing Permissions-Policy - browser features not restricted",
}

INFO_DISCLOSURE_HEADERS = ["Server", "X-Powered-By", "X-AspNet-Version"]

COOKIE_PLATFORM_HINTS = {
    "phpsessid": "PHP (likely Apache/Nginx + PHP)",
    "asp.net_sessionid": "ASP.NET (likely IIS)",
    "jsessionid": "Java (likely Tomcat/JBoss/WebLogic)",
    "laravel_session": "PHP/Laravel",
    "connect.sid": "Node.js (Express)",
    "csrftoken": "Python (possibly Django)",
}

ERROR_PAGE_SIGNATURES = [
    ("nginx", "nginx"),
    ("apache", "Apache"),
    ("iis", "Microsoft IIS"),
    ("cloudflare", "Cloudflare (in front of origin server)"),
]


def guess_server_fallback(url: str):
    """When the 'Server' header is hidden, try a couple of low-noise, read-only
    heuristics (cookie names, default error-page wording) to guess the underlying
    stack. Best-effort only — never definitive, and intentionally avoids anything
    intrusive (no path brute-forcing beyond a single harmless 404 check)."""
    hints = []
    try:
        resp = requests.get(url, timeout=6)
        for cookie_name in resp.cookies.keys():
            hint = COOKIE_PLATFORM_HINTS.get(cookie_name.lower())
            if hint and hint not in hints:
                hints.append(hint)
    except requests.RequestException:
        pass

    try:
        probe_path = url.rstrip("/") + "/scanpro-check-" + "".join(random.choices("abcdefgh", k=8))
        bad = requests.get(probe_path, timeout=6, allow_redirects=False)
        body = (bad.text or "").lower()
        for needle, label in ERROR_PAGE_SIGNATURES:
            if needle in body and label not in hints:
                hints.append(f"{label} (from error page)")
    except requests.RequestException:
        pass

    return hints or None


def normalize_url(target: str) -> str:
    if "://" not in target:
        return f"https://{target}"
    return target


def check_headers(url: str):
    findings = []
    try:
        resp = requests.get(url, timeout=8, verify=True, allow_redirects=True)
    except requests.exceptions.SSLError:
        try:
            resp = requests.get(url, timeout=8, verify=False, allow_redirects=True)
            findings.append({"issue": "SSL certificate validation failed", "severity": "high"})
        except requests.RequestException as e:
            return {"error": str(e)}, []
    except requests.RequestException as e:
        return {"error": str(e)}, []

    headers = resp.headers

    for header, warning in REQUIRED_SECURITY_HEADERS.items():
        if header not in headers:
            findings.append({"issue": warning, "severity": "medium"})

    for header in INFO_DISCLOSURE_HEADERS:
        if header in headers:
            findings.append({
                "issue": f"Information disclosure: '{header}' header reveals '{headers[header]}'",
                "severity": "low",
            })

    if url.startswith("http://"):
        findings.append({"issue": "Site served over plain HTTP, not HTTPS", "severity": "high"})

    return {"status_code": resp.status_code, "headers": dict(headers)}, findings


def check_tls(hostname: str, port: int = 443):
    findings = []
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((hostname, port), timeout=8) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                protocol = ssock.version()

        not_after = cert.get("notAfter")
        if not_after:
            expiry = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
            days_left = (expiry - datetime.datetime.utcnow()).days  # naive UTC compare vs cert's naive expiry
            if days_left < 0:
                findings.append({"issue": f"TLS certificate EXPIRED {abs(days_left)} days ago", "severity": "critical"})
            elif days_left < 30:
                findings.append({"issue": f"TLS certificate expires in {days_left} days", "severity": "medium"})

        if protocol in ("TLSv1", "TLSv1.1", "SSLv3", "SSLv2"):
            findings.append({"issue": f"Outdated/weak TLS protocol in use: {protocol}", "severity": "high"})

        return {"protocol": protocol, "expires": not_after}, findings

    except ssl.SSLCertVerificationError as e:
        return {"error": str(e)}, [{"issue": f"TLS certificate verification failed: {e}", "severity": "high"}]
    except Exception as e:
        return {"error": str(e)}, []


def check_common_paths(url: str):
    """Check for a few commonly-exposed sensitive paths (non-intrusive, read-only)."""
    paths = ["/.git/config", "/.env", "/robots.txt", "/.well-known/security.txt"]
    findings = []
    base = url.rstrip("/")

    for path in paths:
        try:
            resp = requests.get(base + path, timeout=5, allow_redirects=False)
            if resp.status_code == 200:
                if path in ("/.git/config", "/.env"):
                    findings.append({
                        "issue": f"Sensitive file potentially exposed: {path} (HTTP 200)",
                        "severity": "critical",
                    })
        except requests.RequestException:
            continue

    return findings


def scan_web(url: str):
    parsed = urlparse(url)
    hostname = parsed.hostname
    results = {"url": url, "findings": []}

    ip = None
    if hostname:
        try:
            ip = socket.gethostbyname(hostname)
        except socket.error:
            ip = None
    results["hostname"] = hostname
    results["ip"] = ip
    ip_note = f" ({ip})" if ip else " (could not resolve IP)"
    print(f"    Target resolves to {hostname}{ip_note}")

    print(f"    Checking HTTP security headers...")
    meta, header_findings = check_headers(url)
    results["response_meta"] = meta
    results["findings"].extend(header_findings)

    server_header = None
    if isinstance(meta, dict):
        server_header = (meta.get("headers") or {}).get("Server")
    results["server"] = server_header or "not disclosed"

    if server_header:
        print(f"    Web server (from 'Server' header): {results['server']}")
    else:
        fallback_hints = guess_server_fallback(url)
        if fallback_hints:
            results["server_guess"] = fallback_hints
            print(f"    Server header hidden — possible stack (heuristic, not definitive): {', '.join(fallback_hints)}")
        else:
            print(f"    Web server (from 'Server' header): not disclosed (no fallback signal found)")

    if parsed.scheme == "https" and hostname:
        print(f"    Checking TLS/SSL configuration...")
        tls_meta, tls_findings = check_tls(hostname, parsed.port or 443)
        results["tls_meta"] = tls_meta
        results["findings"].extend(tls_findings)

    print(f"    Checking for commonly exposed sensitive paths...")
    results["findings"].extend(check_common_paths(url))

    for f in results["findings"]:
        f.setdefault("remediation", remediation.suggest_for_finding(f))

    for f in results["findings"]:
        color = {"critical": C.RED + C.BOLD, "high": C.RED, "medium": C.YELLOW, "low": C.CYAN}.get(f["severity"], C.CYAN)
        print(f"    {color}[{f['severity']}]{C.END} {f['issue']}")

    return results
