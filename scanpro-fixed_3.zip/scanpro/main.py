#!/usr/bin/env python3
"""
ScanPro - Lightweight Network & Web Vulnerability Assessment Tool
Author: (your name here)
License: MIT

For authorized security assessments only. Only scan systems you own
or have explicit written permission to test.
"""

import argparse
import sys
import json
import socket
from datetime import datetime, timezone

from modules import network_scan, web_scan, cve_lookup, report, subdomain_enum, nuclei_scan, remediation
from modules.colors import C


def banner():
    print(f"""{C.CYAN}
 __     __    _         _                          
 \\ \\   / /   | |       / \\   ___ ___  ___  ___ ___  
  \\ \\ / /_   | | ____ / _ \\ / __/ __|/ _ \\/ __/ __| 
   \\ V / |__ | ||____/ ___ \\\\__ \\__ \\  __/\\__ \\__ \\ 
    \\_/ \\____|_|    /_/   \\_\\___/___/\\___||___/___/ 
{C.END}  Network & Web Vulnerability Assessment Tool
  {C.YELLOW}Use only on systems you are authorized to test.{C.END}
""")


def parse_args():
    p = argparse.ArgumentParser(
        description="ScanPro - vulnerability assessment tool (network + web)"
    )
    p.add_argument("target", help="Target IP, hostname, or URL (e.g. 192.168.1.10 or https://example.com)")
    p.add_argument("--ports", default="1-1024", help="Port range for network scan, e.g. 1-1024 or 22,80,443 (default: 1-1024)")
    p.add_argument("--no-network", action="store_true", help="Skip network/port scan")
    p.add_argument("--no-web", action="store_true", help="Skip web application scan")
    p.add_argument("--no-cve", action="store_true", help="Skip CVE lookup against detected service versions")
    p.add_argument("--threads", type=int, default=100, help="Concurrent threads for port scanning (default: 100)")
    p.add_argument("--timeout", type=float, default=1.0, help="Socket timeout in seconds (default: 1.0)")
    p.add_argument("--os-detect", action="store_true", help="Attempt a best-effort TTL-based OS fingerprint (not definitive)")
    p.add_argument("--stealth", action="store_true", help="Timing-based evasion: lower concurrency, randomized port order, jittered delays (not packet-level stealth)")
    p.add_argument("-o", "--output", help="Output report file (.html, .json, .csv, or .md)")
    p.add_argument("--nvd-api-key", help="Optional NVD API key (raises rate limit from 5 to 50 req/30s)")
    p.add_argument("--subdomains", action="store_true", help="Enumerate subdomains (via crt.sh) and check each for issues")
    p.add_argument("--subdomain-limit", type=int, default=30, help="Max number of discovered subdomains to actively probe (default: 30)")
    p.add_argument("--nuclei", action="store_true", help="Run nuclei against the target's web app, if nuclei is installed")
    p.add_argument("--nuclei-severity", help="Comma-separated severities to pass to nuclei, e.g. critical,high")
    return p.parse_args()


def main():
    args = parse_args()
    banner()

    results = {
        "target": args.target,
        "scan_time": datetime.now(timezone.utc).isoformat(),
        "network": None,
        "web": None,
        "subdomains": None,
        "nuclei": None,
    }

    # ---- Network / host scan ----
    if not args.no_network:
        host = network_scan.resolve_target(args.target)
        if host:
            try:
                _ip_preview = socket.gethostbyname(host)
            except socket.error:
                _ip_preview = "unresolvable"
            print(f"{C.BOLD}[*] Starting network scan on {host} ({_ip_preview}){C.END}")
            net_results = network_scan.scan_host(
                host, args.ports, threads=args.threads, timeout=args.timeout,
                stealth=args.stealth, os_detect=args.os_detect
            )
            results["network"] = net_results

            if not args.no_cve and net_results["open_ports"]:
                print(f"{C.BOLD}[*] Looking up known CVEs for detected services...{C.END}")
                cve_lookup.enrich_with_cves(net_results, api_key=args.nvd_api_key)
        else:
            print(f"{C.RED}[!] Could not resolve target for network scan, skipping.{C.END}")

    # ---- Web application scan ----
    if not args.no_web:
        url = web_scan.normalize_url(args.target)
        print(f"{C.BOLD}[*] Starting web application scan on {url}{C.END}")
        results["web"] = web_scan.scan_web(url)

    # ---- Subdomain enumeration ----
    if args.subdomains:
        print(f"{C.BOLD}[*] Enumerating subdomains...{C.END}")
        results["subdomains"] = subdomain_enum.enumerate_subdomains(
            args.target, limit=args.subdomain_limit, threads=args.threads
        )
        for entry in results["subdomains"]["results"]:
            for f in entry.get("findings", []):
                f.setdefault("remediation", remediation.suggest_for_finding(f))

    # ---- Optional nuclei integration ----
    if args.nuclei:
        print(f"{C.BOLD}[*] Running nuclei...{C.END}")
        nuclei_url = web_scan.normalize_url(args.target)
        nuclei_findings = nuclei_scan.run_nuclei(nuclei_url, severity=args.nuclei_severity)
        if nuclei_findings is not None:
            for f in nuclei_findings:
                f["remediation"] = remediation.suggest_for_finding(f)
        results["nuclei"] = nuclei_findings

    # ---- Report ----
    report.print_summary(results)

    if args.output:
        out = args.output.lower()
        if out.endswith(".json"):
            with open(args.output, "w") as f:
                json.dump(results, f, indent=2, default=str)
        elif out.endswith(".csv"):
            report.write_csv(results, args.output)
        elif out.endswith(".md"):
            report.write_markdown(results, args.output)
        else:
            report.write_html(results, args.output)
        print(f"\n{C.GREEN}[+] Report saved to {args.output}{C.END}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[!] Interrupted by user.")
        sys.exit(1)
